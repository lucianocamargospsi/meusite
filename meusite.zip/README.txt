Projeto: site estático - 'meusite'
Conteúdo: arquivos HTML (index, sobre, contato), CSS, JS e 3 imagens placeholders.
Local dos arquivos no container: /mnt/data/meusite

Substitua as imagens em 'images/' pelas suas fotos finais (mesmos nomes) antes de publicar.
Se quiser imagens em JPG, renomeie ou substitua mantendo os nomes:
  - images/foto1-home.png
  - images/foto2-sobre.png
  - images/foto3-contato.png

ZIP gerado em: /mnt/data/meusite.zip
