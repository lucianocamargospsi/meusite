// Espaço para scripts futuros
console.log('Site carregado — pronto para customizações.');
